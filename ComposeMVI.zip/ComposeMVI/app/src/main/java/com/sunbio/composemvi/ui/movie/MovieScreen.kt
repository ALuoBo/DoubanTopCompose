package com.sunbio.composemvi.ui.movie

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.Card
import androidx.compose.material.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Modifier
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.lifecycle.viewmodel.compose.viewModel
import coil.compose.AsyncImage

import com.sunbio.composemvi.api.MovieItem

@Composable
fun MovieScreen(
viewModel: MovieViewModel = viewModel()
) {

    viewModel.fetchLastedMovies()


    LazyColumn(
        modifier = Modifier.fillMaxSize()
    ) {
        viewModel.uiState.movies?.let {
        items(viewModel.uiState.movies!!){
            movie->
            MovieCard(movie)
        }
        }
    }

}

@Preview(showBackground = true)
@Composable
fun PreMovieScreen() {
    MovieScreen()
}

@Composable
fun MovieCard(movie:MovieItem) {
    val
    Card(
        elevation = 6.dp,
        modifier = Modifier
            .fillMaxWidth()
            .padding(12.dp),
        shape = RoundedCornerShape(15.dp),

    ) {
        Row(
            modifier = Modifier.fillMaxWidth()
        ) {
            AsyncImage(
                model = movie.data[0].poster,
                contentDescription = null
            )
            Text(text = movie.originalName)

        }
    }
}
/*

@Preview(showBackground = true)
@Composable
fun PreMovieCard() {
    MovieCard()
}
*/
